/**
 * @version $Id: system.js,v 1.1 2011/04/07 22:24:37 hannes%helma.at Exp $
 */

exports.engine = "rhino";