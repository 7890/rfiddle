package org.mozilla.javascript.tests.harmony;

import org.mozilla.javascript.drivers.RhinoTest;
import org.mozilla.javascript.drivers.ScriptTestsBase;

@RhinoTest(
    value = "testsrc/jstests/harmony/parse-int-float.js"
)
public class ParseIntFloatTest
    extends ScriptTestsBase
{
}
