
/**
 * @todo: document
 */

QUnit.module('console');

test('Console Interfaces Available', function(){
    
    expect(1);
    ok(console,         'console');
    
});


